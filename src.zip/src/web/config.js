const config = {
  apiUrl: '/api_ryuta_takaki'
};

export default config;