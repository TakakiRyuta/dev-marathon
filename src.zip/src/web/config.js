const config = {
  apiUrl: 'http://localhost:5237'
};

export default config;